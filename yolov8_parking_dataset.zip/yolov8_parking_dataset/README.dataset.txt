# car-space detetection > 2025-05-18 11:14am
https://universe.roboflow.com/ml-4xmv4/car-space-detetection

Provided by a Roboflow user
License: CC BY 4.0

